/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd.h"
#include "stdio.h"
#include "stdbool.h"
#include "string.h"
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
//global
double A;
double PU=2.4,PD=1.2;
double PU_ad=2.4,PD_ad=1.2;
double duty_1,duty_2;
//systick
uint32_t key_ms;
uint32_t lcd_error_ms;
//bool
bool _isMode_High=false;
bool _isLock=false;
bool _isError=false;
bool _is_PD_A_PU=false;
//key
uint8_t key_now,key_up,key_down,key_old;
double* choice=&PU;
//lcd
char buf[21];
uint8_t page=1;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void LED_Dark(void);
void LED_Light(uint16_t GPIO_Pin);
uint8_t Key_Read(void);
void Key_Proc(void);
void LCD_Show(void);
void LCD_Show_Data(void);
void LCD_Show_Para(void);
void LCD_Show_Error(void);
void LED_Proc(void);
uint16_t GetADC(void);
void PWM_Proc(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM15_Init();
  /* USER CODE BEGIN 2 */
	LCD_Init();
  LCD_Clear(Black);
  LCD_SetBackColor(Black);
  LCD_SetTextColor(White);
	LED_Dark();
	HAL_TIM_PWM_Start(&htim15,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		A=GetADC()*3.3/4096;
		if(A>PD_ad && A<PU_ad)	_is_PD_A_PU = true;
		else _is_PD_A_PU = false;
		Key_Proc();
		LCD_Show();
		LED_Proc();
		PWM_Proc();
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV3;
  RCC_OscInitStruct.PLL.PLLN = 20;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void LED_Dark(void){
	HAL_GPIO_WritePin(GPIOC,0XFF<<8,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_RESET);
}
void LED_Light(uint16_t GPIO_Pin){
	LED_Dark();
	HAL_GPIO_WritePin(GPIOC,GPIO_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_RESET);
}
uint8_t Key_Read(void){
	uint8_t val=0;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0)==GPIO_PIN_RESET){
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0)==GPIO_PIN_RESET) val = 1;
	}
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1)==GPIO_PIN_RESET){
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1)==GPIO_PIN_RESET) val = 2;
	}
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2)==GPIO_PIN_RESET){
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2)==GPIO_PIN_RESET) val = 3;
	}
	if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0)==GPIO_PIN_RESET){
		HAL_Delay(10);
		if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0)==GPIO_PIN_RESET) val = 4;
	}
	return val;
}
void Key_Proc(void){
	key_now = Key_Read();
	key_down = key_now&(key_now^key_old);
	key_up = ~key_now&(key_now^key_old);
	key_old = key_now;
	
	if(key_down)	key_ms=0;
	if(key_ms<1500){
		if(key_up==1){
			LCD_Clear(Black);
			if(PU<=PD){
				lcd_error_ms=0;
				_isError = true;
				PD=PD_ad;PU=PU_ad;
				return;
			}
			else{
				PD_ad=PD;PU_ad=PU;
			}
			if(page++ == 2)  page=1;
		}
		if(key_up==2){
			if(page==1)	_isMode_High = !_isMode_High;
			if(page==2){
				if(choice==&PD)	choice = &PU;
				else if(choice==&PU)	choice = &PD;
			}
		}
		if(key_up==3){
			if(page==2){
				if(*choice<=3)	*choice+=0.3;
			}
		}
		if(key_up==4){
			if(page==1){//DATA
				if(_isLock)	_isLock = false;
			}
			else{//PARA
				if(*choice>=0.1)	*choice-=0.3;
				if(*choice<0.3)	*choice=0;
			}
		}
	}
	else{
		if(key_up==1){

		}
		if(key_up==2){
			
		}
		if(key_up==3){
			
		}
		if(key_up==4){
			if(page==1){
				if(!_isLock)	_isLock = true;
			}
		}
	}
}
void LCD_Show_Data(void){
	sprintf(buf,"        DATA         ");
	LCD_DisplayStringLine(Line1,(u8*)buf);
	sprintf(buf,"     A=%.1fV          ",A);
	LCD_DisplayStringLine(Line3,(u8*)buf);
	sprintf(buf,"     P=%d%%-%d%%       ",(int)round(duty_1),(int)round(duty_2));
	LCD_DisplayStringLine(Line4,(u8*)buf);
	if(_isMode_High){
		sprintf(buf,"     MODE=H          ");
		LCD_DisplayStringLine(Line5,(u8*)buf);
	}
	else{
		sprintf(buf,"     MODE=L          ");
		LCD_DisplayStringLine(Line5,(u8*)buf);
	}
	if(_isLock){
		sprintf(buf,"     LOCK=Y          ");
		LCD_DisplayStringLine(Line6,(u8*)buf);
	}
	else{
		sprintf(buf,"     LOCK=N          ");
		LCD_DisplayStringLine(Line6,(u8*)buf);
	}
}
void LCD_Show_Para(void){
	sprintf(buf,"        PARA         ");
	LCD_DisplayStringLine(Line1,(u8*)buf);
	sprintf(buf,"     PU=%.1fV          ",PU);
	LCD_DisplayStringLine(Line3,(u8*)buf);
	sprintf(buf,"     PD=%.1fV          ",PD);
	LCD_DisplayStringLine(Line4,(u8*)buf);
}
void LCD_Show_Error(void){
	if(_isError){
		LCD_Clear(Black);
		lcd_error_ms=0;
		sprintf(buf,"        ERROR         ");
		LCD_DisplayStringLine(Line4,(u8*)buf);
	}
}
void LCD_Show(void){
	if(!_isError){
		switch(page){
			case 1:LCD_Show_Data();break;
			case 2:LCD_Show_Para();break;
		}	
	}
	if(_isError){
		sprintf(buf,"        ERROR         ");
		LCD_DisplayStringLine(Line4,(u8*)buf);
		if(lcd_error_ms>3000){
			_isError = false;
			page = 2;
			LCD_Show();
			lcd_error_ms=0;
		}
	}
}
void LED_Proc(void){
	if(!_isMode_High && !_isLock && !_is_PD_A_PU)				LED_Light(GPIO_PIN_10);
	else if(!_isMode_High && !_isLock && _is_PD_A_PU)		LED_Dark();
	else if(!_isMode_High && _isLock && !_is_PD_A_PU)		LED_Light(GPIO_PIN_9|GPIO_PIN_10);
	else if(!_isMode_High && _isLock && _is_PD_A_PU)		LED_Light(GPIO_PIN_9);
	else if(_isMode_High && !_isLock && !_is_PD_A_PU)		LED_Light(GPIO_PIN_8|GPIO_PIN_10);
	else if(_isMode_High && !_isLock && _is_PD_A_PU)		LED_Light(GPIO_PIN_8);
	else if(_isMode_High && _isLock && !_is_PD_A_PU)		LED_Light(GPIO_PIN_8|GPIO_PIN_10|GPIO_PIN_9);
	else if(_isMode_High && _isLock && _is_PD_A_PU)			LED_Light(GPIO_PIN_9|GPIO_PIN_8);
}
uint16_t GetADC(void){
	uint16_t adc=0;
	HAL_ADC_Start(&hadc1);
	adc = HAL_ADC_GetValue(&hadc1);
	return adc;
}
void PWM_Proc(void){
	if(_isLock){
		
	}
	else{
		duty_1 =30.303030303*A;
		duty_2 = 100 -duty_1;
		if(_isMode_High){
			TIM2->PSC = 400-1;
			TIM15->PSC = 400-1;
		}
		else{
			TIM2->PSC = 4000-1;
			TIM15->PSC = 4000-1;
		}
		TIM2->CCR2 = duty_1;
		TIM15->CCR1 = duty_2;
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
